import streamlit as st

class MultiPage:
    def __init__(self):
        self.pages = []

    def add_page(self, title, func):
        self.pages.append({'title':title, 'function':func})
        
    def run(self):
        FIL = lambda page:page['title']
        page = st.sidebar.selectbox('Menu', self.pages, format_func = FIL)
        #page = {'title':title, 'function':func}
        page['function']() # =func()
