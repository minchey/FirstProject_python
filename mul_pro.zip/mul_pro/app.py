import streamlit as st
from pages import mul
from pages import intro, movie

app = mul.MultiPage()

app.add_page('소개', intro.app)
app.add_page('영화', movie.app)

app.run()
