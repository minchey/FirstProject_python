import requests
import pandas as pd
import streamlit as st
from datetime import datetime as dt
from datetime import timedelta as delta

def movie_rank():

    url = 'http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=c3a0fa760324363ef7cde2afa0d73297&targetDt='

    todays = dt.today()
    tod= todays.strftime(" %Y 년 %m 월 %d 일 ")

    st.header(f'''  {tod} : 영화표 판매량 기준 영화 순위''')

    day = todays-delta(days=1)

    day = day.strftime("%Y%m%d")

    url = url+day

    resp=requests.get(url)

    data=resp.json()['boxOfficeResult']['dailyBoxOfficeList']

    dataframe_of_movie = pd.DataFrame(data)

    df = dataframe_of_movie.loc[:, ['rank', 'movieNm', 'openDt', 'salesAmt']]

    st.dataframe(df)
