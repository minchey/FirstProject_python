import streamlit as st
from utils import film
def app():
    st.write('''영화를 소개 하는 곳입니다.''')
    film.movie_rank()
